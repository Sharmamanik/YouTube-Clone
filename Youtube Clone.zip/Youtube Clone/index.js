
const relatedVideosData = [
    { title: "Related Video 1", thumbnail: "thumbnail1.jpg", videoId: "VIDEO_ID_1" },
    { title: "Related Video 2", thumbnail: "thumbnail2.jpg", videoId: "VIDEO_ID_2" },
    { title: "Related Video 3", thumbnail: "thumbnail3.jpg", videoId: "VIDEO_ID_3" },
];


function loadRelatedVideos() {
    const relatedVideosContainer = document.querySelector('.related-videos');

    relatedVideosData.forEach(video => {
        const videoThumbnail = document.createElement('div');
        videoThumbnail.classList.add('video-thumbnail');

        videoThumbnail.innerHTML = `
            <img src="${video.thumbnail}" alt="Video Thumbnail">
            <h3>${video.title}</h3>
        `;

        videoThumbnail.addEventListener('click', function () {
            loadVideo(video.videoId);
        });

        relatedVideosContainer.appendChild(videoThumbnail);
    });
}

function loadVideo(videoId) {
    const videoContainer = document.querySelector('.video-container iframe');
    const videoTitle = document.querySelector('.video-details h1');


    videoContainer.src = `https://www.youtube.com/embed/${videoId}`;

    const videoDetails = {
        title: "Video Title",
        description: "Video description goes here.",
    };

    videoTitle.textContent = videoDetails.title;
    document.querySelector('.video-details p').textContent = videoDetails.description;
}


document.addEventListener('DOMContentLoaded', function () {
    loadRelatedVideos();

    loadVideo('DEFAULT_VIDEO_ID');
});
